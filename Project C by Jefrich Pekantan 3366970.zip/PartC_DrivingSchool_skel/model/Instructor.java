package model; 

public class Instructor extends Record
{
    
    public Instructor(int id, String name)
    {
       super(id, name);
    }
    
    public int getId()
    {
        return id;
    }
    
    public void add()
    {
        
    }
    
    public String toString()
    {
        return "Instructor: "+ super.toString();
    }
}
 