package model; 

public class DrivingClasses extends Records
{
    
    public DrivingClasses()
    {
        
    }
    public void add(String name, double price)
    {
        DrivingClass drivingClass = new DrivingClass (++id, name, price);
        add(drivingClass);
    } 
    public DrivingClass find(int id)
    {    
        return (DrivingClass) super.find(id); 
    }
}
