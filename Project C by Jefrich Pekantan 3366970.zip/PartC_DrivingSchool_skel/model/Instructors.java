package model;
 
public class Instructors extends Records
{
    
    public Instructors()
    {
      
    }
    public void add(String name)
    {
        Instructor instructor = new Instructor (++id, name);
        add(instructor);
    }
    public Instructor find(int id)
    {    
        return (Instructor) super.find(id); 
    }
     
}
