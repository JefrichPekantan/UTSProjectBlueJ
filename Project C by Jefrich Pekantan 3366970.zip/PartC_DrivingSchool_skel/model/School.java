package model; 
import java.util.*;
public class School 
{
    Instructors instructors = new Instructors ();
    Clients clients = new Clients ();
    DrivingClasses classes = new DrivingClasses ();
    LinkedList<Lesson> lessons = new LinkedList<Lesson>();
    int lessonId = 0;
    public School()
    {
    }
    public void lesson(int instructor, int client, int drivingClass)
    {
        lessons.add(new Lesson(++lessonId, instructors.find(instructor), clients.find(client), classes.find(drivingClass)));
    }
    public String report()
    {
        String str = "";
        str += "Instructors \n" + instructors.toString();
        str += "Clients \n" + clients.toString();
        str += "Classes \n" + classes.toString();
        str += "Lessons \n";
        for(Lesson lesson : lessons)
        {
            str += lesson.toString();
        }
        return str;
    }
    public Instructors instructors()
    {
        return instructors;
    }
    public Clients clients()
    {
        return clients;
    }
    public DrivingClasses classes()
    {
        return classes;
    }
    public LinkedList<Lesson> lessons()
    {
        return lessons;
    }
}
