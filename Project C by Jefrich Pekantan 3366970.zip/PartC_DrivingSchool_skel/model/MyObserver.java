package model; 
/**
 * interface Observer 
 */
public interface MyObserver
{   public void update(); }
 