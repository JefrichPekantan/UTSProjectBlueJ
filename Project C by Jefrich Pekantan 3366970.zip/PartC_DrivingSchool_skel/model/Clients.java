package model;

public class Clients extends Records
{
   
    public Clients()
    {
       
    }

    public void add(String name)
    {
        Client client = new Client (++id, name); 
        add(client);
    }
    public Client find(int id)
    {    
        return (Client) super.find(id); 
    }
}
