import model.*;
//s220
public class Root
{   
    public static void main(String[] args)
    {    
        School school = new School();
        new SchoolWindow(school);   
    } 
}
